# ASRQuant 1.3.0 — Publication-Ready Manuscript

The repository ships the publication-ready ASRQuant 1.3.0 paper in the official ASR Research Team v3 style.

- `ASRQuant_paper.pdf` — final rendered manuscript.
- `main.tex` — complete LaTeX source.
- `asrpaper.cls` — ASR Research Team v3 paper class used by this manuscript.
- `asr_mark_light.png` — ASR publication mark.
- `figures_clean/` — manuscript figures.
- `MANUSCRIPT_METADATA.md` — deposit-ready metadata.
- `PUBLICATION_READINESS_REPORT.md` — editorial, scientific and layout QA.
- `FINAL_LOCAL_VALIDATION.md` — software-validation evidence supporting the manuscript claims.
- `AUDIT_FIXES_v1.3.0_FINAL.md` — final audit-finding treatment.

**Publication date:** September 2026  
**Authors:** Alpha Kabinet TOURE; Srijan Mishra  
**DOI:** 10.5281/zenodo.22812302

The exact PDF should be approved by all authors before external deposit; replace the pending identifier once the selected repository or venue assigns it.
