# ASRQuant 1.3.0 — Publication Readiness Review

**Manuscript:** *Quantitative Research Under Real-World Constraints*  
**Version:** 1.3.0  
**Date reviewed:** September 2026  
**Style:** ASR Research Team Paper Standard v3  
**Status:** Publication-ready manuscript, subject to the human confirmations listed below.

## 1. Editorial and visual QA — PASS

- The manuscript uses the official ASR Research Team v3 LaTeX class and ASR mark.
- Cover, headings, rules, violet accents, two-column body and appendix layout are consistent with the v3 standard.
- The v3 title-spacing bug caused by a vertical-space command remaining in horizontal mode was corrected locally in the class copy used for this manuscript.
- PDF is A4, 14 pages, openable and unencrypted.
- PDF metadata includes title, authors, subject and keywords.
- Final LaTeX compilation reports no overfull boxes, unresolved citations, unresolved references or multiply-defined labels.
- Visual inspection of every rendered page found no clipped text, overlap, black boxes or broken glyphs.
- The former duplicate References heading and metadata-column overlap were removed.

## 2. Scientific-claim reconciliation — PASS for the stated scope

The manuscript was reconciled against the corrected ASRQuant 1.3.0 source artifact and its final local validation record. The paper claims only evidence supported by that artifact:

- 336 passing tests across 36 test modules;
- 84 ASRQuant package modules imported with zero failures in the recorded import sweep;
- 116 stable public API symbols in the compatibility contract;
- 258 recorded top-level callable signatures;
- public API compatibility check PASS;
- release-version check PASS;
- final wheel smoke import reporting version 1.3.0.

The manuscript does **not** convert declared support for other Python/OS combinations into observed results. Hosted multi-OS, security, registry and external-service checks are explicitly described as separate operational gates.

## 3. Independent-audit findings — reconciled

The paper documents and distinguishes confirmed software defects from estimator/convention observations. The independent validation and benchmarking workstream is explicitly credited to Srijan Mishra in the abstract, audit section and author-contribution statement. It includes final treatment for FIND-001, FIND-002, FIND-003, FIND-004, FIND-005, FIND-006, FIND-011, FIND-012, FIND-013, FIND-014 and FIND-015.

The three material numerical issues are presented explicitly:

- uneven-pillar key-rate DV01 partitioning;
- Probabilistic/Deflated Sharpe Ratio scaling;
- implied-volatility inversion at the intrinsic/non-identifiable boundary.

Regression coverage for the corrected contracts is included in the accompanying software artifact.

## 4. Native quantitative-engine independence — PASS

The manuscript and package contain no external quantitative-finance pricing-engine bridge, installation extra, benchmark dependency, or interoperability documentation. Finance-specific pricing, curve, rate-risk, calibration and derivative logic remains implemented within ASRQuant. The manuscript describes validation through analytical identities, round-trip tests, invariants, limiting cases, explicit convention checks and regression tests, while general-purpose scientific libraries are used only for numerical/data primitives where appropriate.

## 5. References — PASS

- 16 bibliography entries are present and every entry is cited in the manuscript.
- No citation key is missing.
- Key bibliographic metadata and DOI strings were rechecked for the core references used in the numerical/statistical discussion, including Black--Scholes, Merton, Vasicek, CIR, Heston, Markowitz, Sharpe, Lo, Newey--West, Engle--Granger, White, Hansen SPA, Bailey/López de Prado and PBO.

## 6. Authorship, disclosure and reproducibility — structurally complete

The manuscript contains:

- author contribution statement;
- data and code availability statement;
- reproducibility statement;
- funding statement;
- competing-interest statement;
- AI-use disclosure limited to final drafting and editorial polishing of the document;
- acknowledgements;
- scientific/financial disclaimer;
- publication metadata.

The manuscript does not contain `1.3.0rc1`, `Sole author`, TODO/TBD placeholders, or unsupported release recommendations.

## 7. Human/external confirmations before public deposit

These are **not software or manuscript defects**, but they cannot be certified automatically:

1. **Co-author approval:** both listed authors should approve the exact PDF that is deposited.
2. **Venue-specific formatting:** the manuscript is ready in the ASR v3 house style. A journal with its own mandatory class/template may require a formatting-only conversion.
3. **Copyright/licence form:** complete any venue-specific author agreement at submission time. The accompanying software remains MIT licensed; the manuscript licence depends on the chosen publication venue.

## 8. Readiness decision

**READY FOR ASR PREPRINT / REPOSITORY SUBMISSION, subject to author approval and any venue-specific submission requirements.**

No unresolved scientific-layout blocker was found in the reviewed final PDF.
